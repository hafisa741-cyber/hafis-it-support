# Hafis IT Support — Software Installation & Remote Setup

Versi ini menggunakan **QR manual sahaja**. Tiada integrasi payment gateway, API key bank, webhook bayaran atau penghantaran WhatsApp automatik.

## Business & harga

- Hafis IT Support
- WhatsApp: 0182103458 (link antarabangsa 60182103458)
- RM14 setiap software; combo 4 software berbeza RM25
- Setiap kumpulan empat mendapat combo; baki dikira harga biasa. Contoh 5 = RM39, 8 = RM50.
- QR asal Touch 'n Go yang diberikan pemilik: public/payment-qr.png
- Nama penerima pada QR: HAFIS AULIA BIN AZAHARI

## Aliran customer

1. Pilih software dan pakej, tambah ke cart.
2. Checkout: nama, persetujuan terma, jumlah dikira semula di server.
3. Order ID dan snapshot pesanan disimpan secara atomic dalam D1.
4. Halaman order memaparkan jumlah tepat, gambar QR asal dan pautan muat turun.
5. Customer membayar menggunakan aplikasi bank/e-wallet yang menyokong QR itu, menyemak nama penerima dan jumlah.
6. Butang “Buka WhatsApp & lampirkan resit” membuka wa.me/60182103458 dengan teks order, nama, senarai software, diskaun dan jumlah.
7. Customer MELAMPIRKAN resit dan menekan SEND sendiri dalam WhatsApp. Website tidak boleh mengesahkan mesej/resit sudah dihantar dan tidak menyimpan gambar resit.
8. Selepas menghantar resit, customer boleh menekan “Saya sudah hantar resit”. Ini hanya makluman customer; status awaiting_review, BUKAN paid.
9. Admin menyemak transaksi sebenar dan mengesahkan bayaran. Customer boleh melihat status pemasangan dan muat turun invoice.

Jangan menandakan bayaran sah berdasarkan gambar resit sahaja. Padankan dana sebenar diterima dalam bank/e-wallet, jumlah dan rujukan transaksi.

## Admin

Buka /admin menggunakan akaun pemilik yang di-allowlist oleh ADMIN_USER_IDS. Auth disediakan oleh Sites. Setiap API admin mengesahkan identity di server, bukan frontend.

- Orders: nama, jumlah, payment, pemasangan, invoice.
- Sahkan bayaran: masukkan rujukan transaksi sebenar, jumlah diterima dan tick bahawa dana telah disemak.
- Jumlah mesti sama dengan order. Rujukan transaksi dinormalkan dan unik bagi pesanan QR, supaya satu transaksi tidak digunakan untuk dua pesanan.
- Confirmation bersifat idempotent; retry tidak menggandakan jualan atau mengundurkan pemasangan Completed.
- Audit menyimpan ID admin, waktu pengesahan dan reference.
- Minta pembetulan resit: admin memberi nota yang dipaparkan kepada customer.
- Installation Pending → In Progress → Completed; Cancelled tidak membuat refund automatik.
- Software & packages: tambah software, harga, pakej, aktif/nyahaktif. Snapshot pesanan lama tidak diubah.
- Jualan hanya menjumlahkan order yang sudah disahkan.

## Stack

React 19 + TypeScript + Vinext daripada starter Sites; Cloudflare Workers, D1 SQLite dan Drizzle migrations.
Node >=22.16, npm, Git untuk development. App menggunakan Sites auth boundary; jangan host Worker terus tanpa auth proxy yang mengesahkan dan menapis identity headers.

Struktur:
- components/storefront.tsx — catalog, cart, checkout
- components/order-page.tsx — QR, WhatsApp, status dan invoice
- components/admin.tsx — pengurusan dan semakan manual
- lib/server.ts — database, validation, authorization, checkout dan verification
- lib/security.mjs — hashing token
- lib/pricing.mjs — combo harga
- lib/invoice.ts — invoice PDF asas
- db/schema.ts, drizzle/ — migration append-only
- tests/ — integration SQLite in-memory, tanpa transaksi sebenar

## Local setup

```sh
npm ci
cp .env.example .dev.vars
npm run build
node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0000_graceful_chat.sql
node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0001_lazy_praxagora.sql
npm run dev
```

PowerShell gunakan Copy-Item .env.example .dev.vars, dan npm.cmd jika npm.ps1 disekat. Jalankan hanya migration yang belum diaplikasi pada DB itu. Data lokal dan hosted berasingan. Untuk ujian admin lokal, ADMIN_USER_IDS=local_seedy; identity mock starter hanya aktif pada loopback development.

## Environment

| Variable | Nilai / kegunaan |
| --- | --- |
| STORE_ENABLED | true untuk menerima pesanan; false untuk menutup checkout |
| BUSINESS_NAME | Hafis IT Support |
| WHATSAPP_NUMBER | 60182103458 |
| PAYMENT_QR_PATH | /payment-qr.png |
| PAYMENT_RECIPIENT | HAFIS AULIA BIN AZAHARI |
| ADMIN_USER_IDS | ID pemilik Sites, simpan server-side |
| APP_URL | Origin hosted |
| COMBO_SIZE | 4 |
| COMBO_PRICE_SEN | 2500 |
| CONTACT_EMAIL | Pilihan, isi email sebenar apabila tersedia |
| TERMS_TEXT / PRIVACY_TEXT | Pilihan untuk menggantikan penerangan servis/data yang dipaparkan |

QR, penerima, business name, nombor WhatsApp sah dan STORE_ENABLED mesti tersedia sebelum checkout. Harga pakej aktif juga mesti sah. Tiada credentials payment diperlukan.

## Security & order state

- Browser menyimpan cart package IDs sahaja; server memuat harga DB.
- Jumlah mesti sepadan dengan jumlah yang customer lihat; perubahan harga menghasilkan 409.
- Satu pakej per software; maksimum 9 software; nilai disimpan dalam integer sen.
- Token checkout 256-bit untuk idempotency. Hash sahaja dalam DB; cookie HttpOnly, SameSite=Lax, Secure pada HTTPS, tempoh 7 hari.
- Order hanya boleh dilihat oleh browser customer dengan cookie atau admin.
- Mutasi browser memerlukan Origin sama.
- Checkout rate limit 8 percubaan baharu per 10 minit/IP.
- SQL berparameter dan batch atomic.
- pending → awaiting_review (makluman customer) → paid (admin sahaja).
- rejected ialah resit yang memerlukan pembetulan; nota admin dipaparkan.
- URL success, klik WhatsApp dan butang makluman resit tidak mengesahkan bayaran.
- Paid tidak boleh diundurkan oleh customer atau makluman resit lama.
- Pembayaran/pembatalan/refund sebenar dibuat di luar website oleh pemilik akaun. Tiada tindakan kewangan automatik.
- Kolum mode/bill_id/collection_id lama dikekalkan untuk sejarah database; order baharu menggunakan manual_qr tanpa bil gateway. Endpoint callback lama memulangkan 410.

## Ujian dan deployment

```sh
npm test
npm run typecheck
npm run build
```

Integration tests menggunakan DB in-memory dan melarang semua fetch gateway. Ia menguji order, QR config, WhatsApp payload, combo, akses, semakan resit, pengesahan admin, rujukan berulang, audit dan invoice.

Publish melalui Sites project_id sedia ada dalam .openai/hosting.json:
1. Test/typecheck/build.
2. Source workflow helper commit/push dan package artifact.
3. Save version dan deploy mengikut audience sedia ada.
4. Sites menerapkan migration baharu dan binding DB.
5. Environment variables diterapkan selepas redeploy.
6. Site masih private untuk pemilik sehingga audience diubah kepada public secara sengaja untuk customer umum. QR manual tidak memerlukan webhook public.

Untuk schema baharu: edit db/schema.ts, npm run db:generate, semak SQL dan tambah migration. Jangan edit migration yang sudah digunakan. Backup D1 sebelum perubahan production.

## Had versi ini

WhatsApp click-to-chat sahaja: customer perlu memilih gambar dan menekan Send. Tiada WhatsApp Business API, notifikasi automatik atau tracking penghantaran. Gambar resit berada dalam WhatsApp, bukan website.

Order recovery merentas device dan email automatik belum disediakan. Akses customer pada browser asal selama 7 hari; admin boleh melihat order selepas itu.

Invoice PDF asas, bukan e-Invois LHDN. Standard Helvetica menukar aksara bukan Latin kepada ?, dan memendekkan teks panjang pada PDF; database/web mengekalkan teks asal.

QR digunakan terus daripada fail pemilik tanpa ubah gambar/kod. Kejayaan scan dan pemindahan sebenar perlu disahkan melalui aplikasi bank/e-wallet oleh pemilik/customer; ujian software tidak membuat bayaran.

## Jadual remote
Checkout memerlukan tarikh dan masa pilihan dalam waktu Malaysia (UTC+8), 24 jam. Server menolak tarikh tidak sah dan masa lalu. Pilihan masa disimpan dengan order dan dipaparkan dalam admin, invoice serta WhatsApp; ia bukan jaminan slot eksklusif. Migration 0002 menambah medan masa dan menyahaktifkan pakej Installation lama tanpa memadam pesanan terdahulu. Hanya Installation + Setup ditawarkan untuk katalog asal.
