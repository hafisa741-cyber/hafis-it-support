import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {build} from 'esbuild';
import {mkdir,readFile,readdir} from 'node:fs/promises';
import {pathToFileURL} from 'node:url';
import {resolve} from 'node:path';
await mkdir('.sites-runtime/tests',{recursive:true});
await build({entryPoints:['app/api/[...path]/route.ts'],bundle:true,platform:'node',format:'esm',outfile:'.sites-runtime/tests/routes.mjs',plugins:[{name:'test-env',setup(b){b.onResolve({filter:/^cloudflare:workers$/},()=>({path:'env',namespace:'test'}));b.onLoad({filter:/.*/,namespace:'test'},()=>({contents:'export const env=globalThis.__TEST_ENV__;'}));}}]});
const sql=new DatabaseSync(':memory:');sql.exec('PRAGMA foreign_keys=ON');
for(const f of (await readdir('drizzle')).filter(f=>f.endsWith('.sql')).sort())sql.exec(await readFile('drizzle/'+f,'utf8'));
function statement(query,args=[]){return {bind(...values){return statement(query,values);},async first(){return sql.prepare(query).get(...args)||null;},async all(){return {results:sql.prepare(query).all(...args)};},async run(){return {meta:{changes:Number(sql.prepare(query).run(...args).changes)}};}};}
const d1={prepare:statement,async batch(stmts){sql.exec('BEGIN');try{const results=[];for(const s of stmts)results.push(await s.run());sql.exec('COMMIT');return results;}catch(e){sql.exec('ROLLBACK');throw e;}}};
const env=globalThis.__TEST_ENV__={DB:d1,ADMIN_USER_IDS:'test-owner',BUSINESS_NAME:'Hafis Aulia',WHATSAPP_NUMBER:'60182103458',COMBO_SIZE:'4',COMBO_PRICE_SEN:'2500'};
const routes=await import(pathToFileURL(resolve('.sites-runtime/tests/routes.mjs')).href);
globalThis.fetch=async()=>{throw new Error('Manual QR must never call a payment provider');};
const origin='https://store.example',owner={'oai-authenticated-user-id':'test-owner'};
function call(path,method='GET',data,headers={}){return routes[method](new Request(origin+'/api/'+path,{method,headers:{...(method==='GET'?{}:{origin,'Content-Type':'application/json'}),...headers},body:data===undefined?undefined:JSON.stringify(data)}));}
const input={name:'Test Buyer',installationDate:'2099-01-01',installationTime:'00:00',items:['photoshop-setup','illustrator-setup','premiere-setup','animate-setup'],expectedAmount:2500,consent:true,checkoutToken:'1'.repeat(64)};
test('manual QR, WhatsApp and admin verification integration',async t=>{
 let orderId,cookie;
 await t.test('admin access and cross-origin writes protected',async()=>{
 assert.equal((await call('admin/dashboard')).status,403);
 assert.equal((await call('admin/seed','POST',{}, {...owner,origin:'https://evil.test'})).status,403);
 assert.equal((await call('admin/seed','POST',{},owner)).status,200);
 });
 await t.test('checkout requires QR and explicit enable; no credentials required',async()=>{
 assert.equal((await call('checkout','POST',input)).status,503);
 Object.assign(env,{STORE_ENABLED:'true',PAYMENT_QR_PATH:'/payment-qr.png',PAYMENT_RECIPIENT:'HAFIS AULIA BIN AZAHARI'});
 assert.equal((await (await call('catalog')).json()).config.ready,true);
 });
 await t.test('unset price and duplicate software rejected',async()=>{
 assert.equal((await call('checkout','POST',input)).status,400);
 sql.exec('UPDATE packages SET price=1400');
 assert.equal((await call('checkout','POST',{...input,items:['photoshop-setup','photoshop-setup'],expectedAmount:2800})).status,400);
 assert.equal((await call('checkout','POST',{...input,expectedAmount:1})).status,409);
 });
 await t.test('creates unpaid combo order and idempotent retry',async()=>{
 const r=await call('checkout','POST',input);assert.equal(r.status,201);const data=await r.json();orderId=data.orderId;cookie=r.headers.get('Set-Cookie').split(';')[0];assert.equal(data.url,'/orders/'+orderId);
 const repeat=await (await call('checkout','POST',input)).json();assert.equal(repeat.orderId,orderId);assert.equal(sql.prepare('SELECT COUNT(*) n FROM orders').get().n,1);
 });
 await t.test('WhatsApp text contains order, software and exact amount without claiming paid',async()=>{
 const r=await call('orders/'+orderId,'GET',undefined,{cookie});const o=await r.json();
 assert.equal(o.amount,2500);assert.equal(o.discount,3100);assert.equal(o.mode,'manual_qr');assert.equal(o.payment_status,'pending');assert.equal(o.qrPath,'/payment-qr.png');
 const wa=new URL(o.whatsapp);assert.equal(wa.pathname,'/60182103458');const message=wa.searchParams.get('text');for(const value of [orderId,'Test Buyer','Adobe Photoshop','RM 25.00','Belum disahkan','01/01/2099','00:00'])assert.ok(message.includes(value));assert.equal(o.access_hash,undefined);
 });
 await t.test('URL paid flag and refresh cannot confirm; legacy callback disabled',async()=>{
 assert.equal((await (await call('orders/'+orderId+'?paid=true','GET',undefined,{cookie})).json()).payment_status,'pending');
 assert.equal((await (await call('orders/'+orderId+'/refresh','POST',{}, {cookie})).json()).payment_status,'pending');
 assert.equal((await call('payment/callback/sandbox','POST',{})).status,410);
 });
 await t.test('customer access and receipt notice protected',async()=>{
 assert.equal((await call('orders/'+orderId)).status,403);
 assert.equal((await call('orders/'+orderId+'/receipt','POST',{})).status,403);
 assert.equal((await call('orders/'+orderId+'/receipt','POST',{}, {cookie,origin:'https://evil.test'})).status,403);
 const o=await (await call('orders/'+orderId+'/receipt','POST',{}, {cookie})).json();assert.equal(o.payment_status,'awaiting_review');assert.ok(o.receipt_claimed_at);
 assert.equal((await call('admin/orders/'+orderId+'/confirm-payment','POST',{reference:'REF-1',amount:2500,fundsVerified:true},{cookie})).status,403);
 });
 await t.test('admin can request corrected receipt but cannot complete unpaid installation',async()=>{
 assert.equal((await call('admin/orders/'+orderId,'PATCH',{status:'Completed'},owner)).status,400);
 assert.equal((await call('admin/orders/'+orderId+'/reject-receipt','POST',{note:'Rujukan tidak jelas.'},owner)).status,200);
 let o=await (await call('orders/'+orderId,'GET',undefined,{cookie})).json();assert.equal(o.payment_status,'rejected');assert.equal(o.review_note,'Rujukan tidak jelas.');
 o=await (await call('orders/'+orderId+'/receipt','POST',{}, {cookie})).json();assert.equal(o.payment_status,'awaiting_review');
 });
 await t.test('confirmation needs actual matching amount, reference and acknowledgment',async()=>{
 const endpoint='admin/orders/'+orderId+'/confirm-payment';
 for(const b of [{reference:'REF-1',amount:2500,fundsVerified:false},{reference:'REF-1',amount:1400,fundsVerified:true},{reference:'',amount:2500,fundsVerified:true}])assert.equal((await call(endpoint,'POST',b,owner)).status,400);
 assert.equal((await call(endpoint,'POST',{reference:'ref-1',amount:2500,fundsVerified:true},owner)).status,200);
 const o=sql.prepare('SELECT * FROM orders WHERE id=?').get(orderId);assert.equal(o.payment_status,'paid');assert.equal(o.paid_by,'test-owner');assert.equal(o.transaction_ref,'REF-1');assert.equal(o.installation_status,'Installation Pending');
 });
 await t.test('confirmation retries and receipt clicks never regress paid or completed',async()=>{
 await call('admin/orders/'+orderId,'PATCH',{status:'Completed'},owner);
 await call('admin/orders/'+orderId+'/confirm-payment','POST',{reference:'REF-1',amount:2500,fundsVerified:true},owner);
 await call('orders/'+orderId+'/receipt','POST',{}, {cookie});
 const o=sql.prepare('SELECT * FROM orders WHERE id=?').get(orderId);assert.equal(o.payment_status,'paid');assert.equal(o.installation_status,'Completed');
 assert.equal(sql.prepare("SELECT COUNT(*) n FROM payment_events WHERE id=?").get('manual-confirm:'+orderId).n,1);
 assert.equal((await call('admin/orders/'+orderId+'/reject-receipt','POST',{note:'wrong'},owner)).status,409);
 });
 await t.test('sales count only confirmed amounts; PDF includes combo discount',async()=>{
 const d=await (await call('admin/dashboard','GET',undefined,owner)).json();assert.equal(d.stats.sales,2500);assert.equal(d.stats.review_count,0);
 const pdf=await (await call('orders/'+orderId+'/invoice','GET',undefined,owner)).text();assert.ok(pdf.startsWith('%PDF-1.4'));assert.match(pdf,/BUNDLE DISCOUNT: -MYR 31.00/);
 });
 await t.test('transaction reference cannot be reused on another order; cancelled cannot confirm',async()=>{
 const r=await call('checkout','POST',{...input,checkoutToken:'2'.repeat(64)},{'cf-connecting-ip':'second-test'});const o=await r.json();assert.equal(r.status,201);
 assert.equal((await call('admin/orders/'+o.orderId+'/confirm-payment','POST',{reference:' ref-1 ',amount:2500,fundsVerified:true},owner)).status,409);
 assert.equal(sql.prepare('SELECT payment_status FROM orders WHERE id=?').get(o.orderId).payment_status,'pending');
 await call('admin/orders/'+o.orderId,'PATCH',{status:'Cancelled'},owner);
 assert.equal((await call('admin/orders/'+o.orderId+'/confirm-payment','POST',{reference:'REF-2',amount:2500,fundsVerified:true},owner)).status,409);
 });
});
