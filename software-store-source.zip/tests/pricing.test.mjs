import test from 'node:test';
import assert from 'node:assert/strict';
import {quote} from '../lib/pricing.mjs';
test('RM14 software, automatic RM25 per group of four',()=>{
 const bundle={size:4,price:2500};
 for(const [count,total] of [[1,1400],[2,2800],[3,4200],[4,2500],[5,3900],[6,5300],[7,6700],[8,5000],[9,6400]])assert.equal(quote(Array(count).fill(1400),bundle).total,total);
 assert.deepEqual(quote([1400,1400,1400,1400],bundle),{subtotal:5600,total:2500,discount:3100,combos:1});
});
test('bundle never increases price; unset promotion preserves normal pricing',()=>{
 assert.equal(quote([100,100,100,100],{size:4,price:2500}).total,400);
 assert.equal(quote([1400,1400,1400,1400],null).total,5600);
});
