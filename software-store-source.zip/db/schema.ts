import { sqliteTable, text, integer, uniqueIndex } from 'drizzle-orm/sqlite-core';
export const products = sqliteTable('products', {
 id: text('id').primaryKey(), name: text('name').notNull(), category: text('category').notNull(),
 description: text('description').notNull(), monogram: text('monogram').notNull(), color: text('color').notNull(), active: integer('active').notNull().default(1),
});
export const packages = sqliteTable('packages', {
 id: text('id').primaryKey(), productId: text('product_id').notNull().references(()=>products.id),
 name: text('name').notNull(), description: text('description').notNull(), price: integer('price'), active: integer('active').notNull().default(1),
});
export const customers = sqliteTable('customers', {
 id: text('id').primaryKey(), name: text('name').notNull(), email: text('email').notNull(), createdAt: text('created_at').notNull(),
});
export const orders = sqliteTable('orders', {
 id: text('id').primaryKey(), customerId: text('customer_id').notNull().references(()=>customers.id),
 accessHash: text('access_hash').notNull(), amount: integer('amount').notNull(), paymentStatus: text('payment_status').notNull().default('pending'),
 installationStatus: text('installation_status').notNull().default('Pending Payment'), mode: text('mode').notNull(),
 billId: text('bill_id'), billUrl: text('bill_url'), collectionId: text('collection_id').notNull(), transactionRef: text('transaction_ref'),
 createdAt: text('created_at').notNull(), paidAt: text('paid_at'), checkedAt: integer('checked_at').notNull().default(0),
 creationState: text('creation_state').notNull().default('creating'),
 preferredInstallationAt:text('preferred_installation_at'),
 paidBy: text('paid_by'), receiptClaimedAt:text('receipt_claimed_at'), reviewNote:text('review_note'),
}, (t)=>[uniqueIndex('orders_access_unique').on(t.accessHash),uniqueIndex('orders_bill_unique').on(t.billId),uniqueIndex('orders_transaction_mode_unique').on(t.mode,t.transactionRef)]);
export const items = sqliteTable('order_items', {
 id: text('id').primaryKey(), orderId: text('order_id').notNull().references(()=>orders.id),
 productName: text('product_name').notNull(), packageName: text('package_name').notNull(), packageId: text('package_id').notNull(), price: integer('price').notNull(),
});
export const events = sqliteTable('payment_events', {
 id: text('id').primaryKey(), orderId: text('order_id').notNull().references(()=>orders.id), kind: text('kind').notNull(), createdAt: text('created_at').notNull(),
});
export const limits = sqliteTable('rate_limits', { id: text('id').primaryKey(), hits: integer('hits').notNull(), expiresAt: integer('expires_at').notNull() });
