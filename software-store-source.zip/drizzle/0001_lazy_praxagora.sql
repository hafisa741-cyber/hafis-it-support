ALTER TABLE `orders` ADD `paid_by` text;--> statement-breakpoint
ALTER TABLE `orders` ADD `receipt_claimed_at` text;--> statement-breakpoint
ALTER TABLE `orders` ADD `review_note` text;--> statement-breakpoint
CREATE UNIQUE INDEX `orders_transaction_mode_unique` ON `orders` (`mode`,`transaction_ref`);