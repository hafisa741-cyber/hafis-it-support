ALTER TABLE `orders` ADD `preferred_installation_at` text;
--> statement-breakpoint
UPDATE packages SET active=0 WHERE id IN ('photoshop-install','illustrator-install','premiere-install','animate-install','autocad-install','sketchup-install','solidworks-install','spss-install','office-install');
--> statement-breakpoint
UPDATE packages SET name='Installation + Setup' WHERE id IN ('photoshop-setup','illustrator-setup','premiere-setup','animate-setup','autocad-setup','sketchup-setup','solidworks-setup','spss-setup','office-setup');
