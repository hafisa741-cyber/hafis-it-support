CREATE TABLE `customers` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`email` text NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `payment_events` (
	`id` text PRIMARY KEY NOT NULL,
	`order_id` text NOT NULL,
	`kind` text NOT NULL,
	`created_at` text NOT NULL,
	FOREIGN KEY (`order_id`) REFERENCES `orders`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE TABLE `order_items` (
	`id` text PRIMARY KEY NOT NULL,
	`order_id` text NOT NULL,
	`product_name` text NOT NULL,
	`package_name` text NOT NULL,
	`package_id` text NOT NULL,
	`price` integer NOT NULL,
	FOREIGN KEY (`order_id`) REFERENCES `orders`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE TABLE `rate_limits` (
	`id` text PRIMARY KEY NOT NULL,
	`hits` integer NOT NULL,
	`expires_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `orders` (
	`id` text PRIMARY KEY NOT NULL,
	`customer_id` text NOT NULL,
	`access_hash` text NOT NULL,
	`amount` integer NOT NULL,
	`payment_status` text DEFAULT 'pending' NOT NULL,
	`installation_status` text DEFAULT 'Pending Payment' NOT NULL,
	`mode` text NOT NULL,
	`bill_id` text,
	`bill_url` text,
	`collection_id` text NOT NULL,
	`transaction_ref` text,
	`created_at` text NOT NULL,
	`paid_at` text,
	`checked_at` integer DEFAULT 0 NOT NULL,
	`creation_state` text DEFAULT 'creating' NOT NULL,
	FOREIGN KEY (`customer_id`) REFERENCES `customers`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `orders_access_unique` ON `orders` (`access_hash`);--> statement-breakpoint
CREATE UNIQUE INDEX `orders_bill_unique` ON `orders` (`bill_id`);--> statement-breakpoint
CREATE TABLE `packages` (
	`id` text PRIMARY KEY NOT NULL,
	`product_id` text NOT NULL,
	`name` text NOT NULL,
	`description` text NOT NULL,
	`price` integer,
	`active` integer DEFAULT 1 NOT NULL,
	FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE TABLE `products` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`category` text NOT NULL,
	`description` text NOT NULL,
	`monogram` text NOT NULL,
	`color` text NOT NULL,
	`active` integer DEFAULT 1 NOT NULL
);
