export const initialCatalog = [
 ['photoshop','Adobe Photoshop','Creative','Sunting foto, retouch dan hasilkan visual yang lebih tajam.','Ps','#68b9f9'],
 ['illustrator','Adobe Illustrator','Creative','Reka logo, ilustrasi vektor dan identiti visual.','Ai','#f4b45e'],
 ['premiere','Adobe Premiere Pro','Creative','Susun rakaman, sunting video dan sediakan hasil akhir.','Pr','#b4a0f7'],
 ['animate','Adobe Animate','Creative','Hidupkan idea melalui animasi dan kandungan interaktif.','An','#e5a5f6'],
 ['autocad','AutoCAD','Engineering','Sediakan persekitaran untuk lukisan teknikal dan drafting.','Ac','#f28591'],
 ['sketchup','SketchUp','Engineering','Bina model 3D untuk ruang, struktur dan idea anda.','Sk','#77afd8'],
 ['solidworks','SolidWorks','Engineering','Mulakan pemodelan komponen dan reka bentuk mekanikal.','Sw','#ef9981'],
 ['spss','SPSS','Productivity','Sediakan workspace analisis data dan statistik.','Sp','#8acbbd'],
 ['office','Microsoft Office','Productivity','Lengkapkan workspace dokumen, spreadsheet dan presentation.','Of','#e6a180'],
].map(([id,name,category,description,monogram,color])=>({id,name,category,description,monogram,color,active:1,packages:[
 {id:id+'-setup',product_id:id,name:'Installation + Setup',description:'Pemasangan dan konfigurasi asas melalui remote session pada 1 komputer.',price:null as number|null,active:1}
]}));