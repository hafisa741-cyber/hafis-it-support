import { env } from 'cloudflare:workers';
import { initialCatalog } from './catalog';
import { quote } from './pricing.mjs';
import { installationTime, scheduleLabel } from './schedule.mjs';
import { sha256, equalHex } from './security.mjs';
const e=()=>env as unknown as Record<string,any>;
export const db=()=>{if(!e().DB)throw new HttpError(503,'Database belum tersedia.');return e().DB as D1Database;};
export class HttpError extends Error { constructor(public status:number,message:string){super(message);} }
export const fail=(status:number,message:string):never=>{throw new HttpError(status,message);};
export const json=(data:any,status=200,headers:Record<string,string>={})=>Response.json(data,{status,headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer',...headers}});
export async function guard(fn:()=>Promise<Response>){try{return await fn();}catch(err){if(err instanceof HttpError)return json({error:err.message},err.status);console.error('Request failed:',err instanceof Error?err.name:'unknown');return json({error:'Permintaan tidak dapat diproses. Sila cuba lagi atau hubungi admin.'},500);}}
export function originGuard(req:Request){if(req.headers.get('origin')!==new URL(req.url).origin)fail(403,'Origin tidak dibenarkan.');}
export async function body(req:Request){if(Number(req.headers.get('content-length')||0)>16384)fail(413,'Permintaan terlalu besar.');const raw=await req.text();if(raw.length>16384)fail(413,'Permintaan terlalu besar.');try{return JSON.parse(raw);}catch{fail(400,'JSON tidak sah.');}}
export function textValue(v:any,max=120){if(typeof v!=='string'||!v.trim()||v.trim().length>max)fail(400,'Sila lengkapkan maklumat yang sah.');return v.trim();}
export function admin(req:Request){const id=req.headers.get('oai-authenticated-user-id');const allowed=String(e().ADMIN_USER_IDS||'').split(',').map(s=>s.trim()).filter(Boolean);if(!id||!allowed.includes(id))fail(403,'Akses admin belum dibenarkan untuk akaun ini.');return id;}
export function isAdmin(req:Request){try{admin(req);return true;}catch{return false;}}
export function config(){
 const whatsappConfigured=/^[1-9][0-9]{7,14}$/.test(e().WHATSAPP_NUMBER||'');
 const qrPath=e().PAYMENT_QR_PATH==='/payment-qr.png'?'/payment-qr.png':null;
 const ready=!!(e().STORE_ENABLED==='true'&&qrPath&&e().PAYMENT_RECIPIENT&&e().BUSINESS_NAME&&whatsappConfigured);
 const size=Number(e().COMBO_SIZE),price=Number(e().COMBO_PRICE_SEN);const bundle=Number.isInteger(size)&&size>=2&&size<=9&&Number.isInteger(price)&&price>=100?{size,price}:null;
 return {mode:'manual_qr',ready,bundle,qrPath,recipient:e().PAYMENT_RECIPIENT||'',businessName:e().BUSINESS_NAME||'',contactEmail:e().CONTACT_EMAIL||'',whatsappConfigured,
 terms:e().TERMS_TEXT||'Servis pemasangan dan remote setup untuk satu komputer bagi setiap pakej. Lesen software tidak termasuk. Pilih software yang serasi dengan komputer anda dan sediakan lesen sah. Bayar jumlah tepat melalui QR, kemudian hantar resit dan Order ID ke WhatsApp. Pilih tarikh dan masa remote sepanjang 24 jam (waktu Malaysia). Masa pilihan disemak bersama admin melalui WhatsApp selepas bayaran disahkan. Hubungi kami melalui WhatsApp untuk pertanyaan, perubahan tempahan atau permohonan pembatalan.',
 privacy:e().PRIVACY_TEXT||'Nama, tarikh dan masa pemasangan pilihan, pilihan software, jumlah pesanan dan status bayaran disimpan dalam database website untuk mengurus tempahan. Resit dihantar sendiri oleh customer melalui WhatsApp kepada Hafis IT Support; website tidak memuat naik atau menyimpan gambar resit. Maklumat kad dan akses akaun bank tidak diminta. Butiran order yang dipaparkan akan dimasukkan dalam teks WhatsApp apabila anda membuka butang tersebut. Hubungi kami di WhatsApp 0182103458 untuk pertanyaan tentang data pesanan.'};
}
export async function catalog(all=false){
 const ps=await db().prepare('SELECT * FROM products'+(all?'':' WHERE active=1')+' ORDER BY rowid').all();
 const pk=await db().prepare('SELECT * FROM packages'+(all?'':' WHERE active=1')+' ORDER BY rowid').all();
 if(!ps.results.length){const count:any=await db().prepare('SELECT COUNT(*) total FROM products').first();return !all&&!count.total?initialCatalog:[];}
 return ps.results.map((p:any)=>({...p,packages:pk.results.filter((k:any)=>k.product_id===p.id)}));
}
export async function seed(){
 const statements:any[]=[];for(const p of initialCatalog){statements.push(db().prepare('INSERT OR IGNORE INTO products (id,name,category,description,monogram,color,active) VALUES (?,?,?,?,?,?,1)').bind(p.id,p.name,p.category,p.description,p.monogram,p.color));for(const k of p.packages)statements.push(db().prepare('INSERT OR IGNORE INTO packages (id,product_id,name,description,price,active) VALUES (?,?,?,?,NULL,1)').bind(k.id,p.id,k.name,k.description));}await db().batch(statements);
}
export async function rate(req:Request,scope:string,max=10){
 const now=Math.floor(Date.now()/1000);const slot=Math.floor(now/600);const id=await sha256(scope+':'+(req.headers.get('cf-connecting-ip')||'local')+':'+slot);
 const row:any=await db().prepare('INSERT INTO rate_limits(id,hits,expires_at) VALUES(?,1,?) ON CONFLICT(id) DO UPDATE SET hits=hits+1 RETURNING hits').bind(id,now+1200).first();
 if(row.hits>max)fail(429,'Terlalu banyak percubaan. Cuba semula dalam 10 minit.');
 await db().prepare('DELETE FROM rate_limits WHERE expires_at<?').bind(now).run();
}
export function accessCookie(id:string,token:string,req:Request){return 'order_'+id+'='+token+'; Path=/; HttpOnly; SameSite=Lax; Max-Age=604800'+(new URL(req.url).protocol==='https:'?'; Secure':'');}
export async function loadOrder(id:string){
 const o:any=await db().prepare('SELECT o.*,c.name,c.email FROM orders o JOIN customers c ON c.id=o.customer_id WHERE o.id=?').bind(id).first();if(!o)fail(404,'Pesanan tidak dijumpai.');return o;
}
export async function authorizedOrder(req:Request,id:string){
 const o=await loadOrder(id);if(isAdmin(req))return o;
 const cookie=(req.headers.get('cookie')||'').split(';').map(s=>s.trim()).find(s=>s.startsWith('order_'+id+'='))?.split('=')[1]||'';
 if(!/^[a-f0-9]{64}$/.test(cookie)||!equalHex(await sha256(cookie),o.access_hash))fail(403,'Buka pesanan melalui browser yang digunakan semasa checkout.');return o;
}
export async function orderView(o:any){
 const result=await db().prepare('SELECT product_name,package_name,price FROM order_items WHERE order_id=? ORDER BY rowid').bind(o.id).all();
 const {access_hash,customer_id,checked_at,paid_by,...safe}=o;
 const cfg=config(),number=String(e().WHATSAPP_NUMBER||'');
 const subtotal=result.results.reduce((n:number,i:any)=>n+i.price,0);
 const message=['Salam Hafis IT Support, saya ingin urus tempahan ini.','Order ID: '+o.id,'Nama: '+o.name,'Masa pemasangan pilihan: '+scheduleLabel(o.preferred_installation_at),'',...result.results.map((i:any)=>i.product_name+' — '+i.package_name),'',...(subtotal>o.amount?['Diskaun combo: RM '+((subtotal-o.amount)/100).toFixed(2)]:[]),'Jumlah: RM '+(o.amount/100).toFixed(2),'Status: '+(o.payment_status==='paid'?'Disahkan oleh admin':'Belum disahkan'),'',o.payment_status==='paid'?'Saya ingin menyelaras sesi pemasangan.':'Saya akan lampirkan resit pembayaran untuk semakan.'].join('\n');
 const whatsapp=/^[1-9][0-9]{7,14}$/.test(number)?'https://wa.me/'+number+'?text='+encodeURIComponent(message):null;
 return {...safe,items:result.results,whatsapp,subtotal,discount:subtotal-o.amount,businessName:cfg.businessName,qrPath:cfg.qrPath,recipient:cfg.recipient};
}
export async function receiptNotice(req:Request,o:any){
 originGuard(req);if(o.mode!=='manual_qr')fail(409,'Pesanan ini bukan pembayaran QR manual.');
 if(o.installation_status==='Cancelled')fail(409,'Pesanan telah dibatalkan. Hubungi WhatsApp untuk semakan.');
 await db().prepare("UPDATE orders SET payment_status='awaiting_review',receipt_claimed_at=COALESCE(receipt_claimed_at,?),review_note=NULL WHERE id=? AND payment_status IN ('pending','rejected')").bind(new Date().toISOString(),o.id).run();
 return json(await orderView(await loadOrder(o.id)));
}
export async function confirmPayment(req:Request,o:any,b:any){
 const actor=admin(req);originGuard(req);
 if(o.mode!=='manual_qr')fail(409,'Hanya bayaran QR manual boleh disahkan di sini.');
 if(o.payment_status==='paid')return json({ok:true,alreadyConfirmed:true});
 if(o.installation_status==='Cancelled')fail(409,'Pesanan dibatalkan. Semak dengan customer sebelum meneruskan.');
 const reference=textValue(b.reference,120).toUpperCase().replace(/\s+/g,'');
 if(reference.length<3||b.fundsVerified!==true||b.amount!==o.amount)fail(400,'Semak jumlah sebenar diterima, rujukan transaksi dan pengesahan dana.');
 const now=new Date().toISOString();
 try{await db().batch([
 db().prepare("UPDATE orders SET payment_status='paid',installation_status='Installation Pending',transaction_ref=?,paid_at=?,paid_by=?,review_note=NULL WHERE id=? AND payment_status!='paid' AND installation_status!='Cancelled'").bind(reference,now,actor,o.id),
 db().prepare("INSERT OR IGNORE INTO payment_events(id,order_id,kind,created_at) SELECT ?,id,?,? FROM orders WHERE id=? AND payment_status='paid'").bind('manual-confirm:'+o.id,JSON.stringify({event:'manual_confirmed',actor}),now,o.id)
 ]);}catch(err){const duplicate:any=await db().prepare("SELECT id FROM orders WHERE mode='manual_qr' AND transaction_ref=? AND id!=?").bind(reference,o.id).first();if(duplicate)fail(409,'Rujukan transaksi ini telah digunakan untuk pesanan lain.');throw err;}
 return json({ok:true});
}
export async function rejectReceipt(req:Request,o:any,b:any){
 const actor=admin(req);originGuard(req);if(o.mode!=='manual_qr'||o.payment_status==='paid'||o.installation_status==='Cancelled')fail(409,'Status pesanan ini tidak boleh ditolak.');
 const note=textValue(b.note,300);
 await db().batch([db().prepare("UPDATE orders SET payment_status='rejected',review_note=? WHERE id=? AND payment_status!='paid'").bind(note,o.id),db().prepare('INSERT INTO payment_events(id,order_id,kind,created_at) VALUES(?,?,?,?)').bind(crypto.randomUUID(),o.id,JSON.stringify({event:'receipt_rejected',actor}),new Date().toISOString())]);
 return json({ok:true});
}
export async function checkout(req:Request){
 originGuard(req);const b=await body(req);
 if(!/^[a-f0-9]{64}$/.test(b.checkoutToken||''))fail(400,'Sesi checkout tidak sah.');
 const hash=await sha256(b.checkoutToken);
 const existing:any=await db().prepare('SELECT id FROM orders WHERE access_hash=?').bind(hash).first();
 if(existing){const o=await loadOrder(existing.id);return json({orderId:o.id,url:'/orders/'+o.id,pending:o.payment_status!=='paid'},200,{'Set-Cookie':accessCookie(o.id,b.checkoutToken,req)});}
 const cfg=config();if(!cfg.ready)fail(503,'Checkout belum diaktifkan. QR, nama penerima dan nombor WhatsApp perlu dilengkapkan oleh admin.');
 await rate(req,'checkout',8);
 const name=textValue(b.name,100),email='';
 let preferredInstallationAt:string;try{preferredInstallationAt=installationTime(b.installationDate,b.installationTime);}catch(err){fail(400,(err as Error).message);}
 if(b.consent!==true)fail(400,'Persetujuan terma diperlukan.');
 if(!Array.isArray(b.items)||!b.items.length||b.items.length>9||new Set(b.items).size!==b.items.length)fail(400,'Pilih 1 hingga 9 pakej berbeza.');
 const rows:any[]=[];for(const id of b.items){if(typeof id!=='string')fail(400,'Pakej tidak sah.');const r:any=await db().prepare('SELECT k.*,p.name AS product_name FROM packages k JOIN products p ON p.id=k.product_id WHERE k.id=? AND k.active=1 AND p.active=1').bind(id).first();if(!r||!Number.isInteger(r.price)||r.price<100)fail(400,'Harga pakej belum tersedia. Sila semak cart.');rows.push(r);}
 if(new Set(rows.map(r=>r.product_id)).size!==rows.length)fail(400,'Pilih satu pakej sahaja untuk setiap software. Combo memerlukan software berbeza.');
 const amount=quote(rows.map(r=>r.price),cfg.bundle).total;if(amount>3000000)fail(400,'Jumlah melebihi had checkout.');
 if(b.expectedAmount!==amount)fail(409,'Harga telah berubah. Muat semula katalog dan semak jumlah sebelum bayar.');
 const id='ORD-'+crypto.randomUUID().replaceAll('-','').slice(0,16).toUpperCase(),cid=crypto.randomUUID(),now=new Date().toISOString();
 const stmts=[db().prepare('INSERT INTO customers(id,name,email,created_at) VALUES(?,?,?,?)').bind(cid,name,email,now),db().prepare("INSERT INTO orders(id,customer_id,access_hash,amount,mode,collection_id,created_at,preferred_installation_at,creation_state) VALUES(?,?,?,?,?,?,?,?,'ready')").bind(id,cid,hash,amount,'manual_qr','manual_qr',now,preferredInstallationAt!),...rows.map(r=>db().prepare('INSERT INTO order_items(id,order_id,product_name,package_name,package_id,price) VALUES(?,?,?,?,?,?)').bind(crypto.randomUUID(),id,r.product_name,r.name,r.id,r.price))];
 try{await db().batch(stmts);}catch(err){const winner:any=await db().prepare('SELECT id FROM orders WHERE access_hash=?').bind(hash).first();if(winner)return json({orderId:winner.id,pending:true},200,{'Set-Cookie':accessCookie(winner.id,b.checkoutToken,req)});throw err;}
 return json({orderId:id,url:'/orders/'+id},201,{'Set-Cookie':accessCookie(id,b.checkoutToken,req)});
}
