import { guard,json,fail,body,originGuard,admin,isAdmin,db,config,catalog,seed,checkout,authorizedOrder,orderView,loadOrder,textValue,receiptNotice,confirmPayment,rejectReceipt } from '../../../lib/server';
import { invoicePdf } from '../../../lib/invoice';
export const dynamic='force-dynamic';
async function handler(req:Request){return guard(async()=>{
 const u=new URL(req.url),p=u.pathname.slice(5).split('/'),method=req.method;
 if(p[0]==='catalog'&&method==='GET')return json({products:await catalog(),config:config()});
 if(p[0]==='checkout'&&method==='POST')return checkout(req);
 if(p[0]==='payment'&&p[1]==='callback')return json({error:'Pembayaran gateway tidak digunakan.'},410);
 if(p[0]==='orders'&&p[1]){
  const o=await authorizedOrder(req,p[1]);
  if(p[2]==='refresh'&&method==='POST'){originGuard(req);return json(await orderView(await loadOrder(o.id)));}
  if(p[2]==='receipt'&&method==='POST')return receiptNotice(req,o);
  if(p[2]==='invoice'&&method==='GET'){const view=await orderView(o);return new Response(invoicePdf(o,view.items,config().businessName||'Software installation service'),{headers:{'Content-Type':'application/pdf','Content-Disposition':'attachment; filename="'+o.id+'.pdf"','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});}
  if(method==='GET'&&!p[2])return json(await orderView(o));
 }
 if(p[0]==='admin'){
  if(p[1]==='session'&&method==='GET')return json({authenticated:!!req.headers.get('oai-authenticated-user-id'),admin:isAdmin(req),userId:req.headers.get('oai-authenticated-user-id')||null});
  admin(req);
  if(method!=='GET')originGuard(req);
  if(p[1]==='seed'&&method==='POST'){await seed();return json({ok:true});}
  if(p[1]==='dashboard'&&method==='GET'){
   const page=Math.max(0,Math.min(10000,Number(u.searchParams.get('page'))||0));
   const orders=await db().prepare('SELECT o.id,o.amount,o.payment_status,o.installation_status,o.mode,o.created_at,o.bill_id,o.creation_state,c.name,c.email FROM orders o JOIN customers c ON c.id=o.customer_id ORDER BY o.created_at DESC LIMIT 50 OFFSET ?').bind(page*50).all();
   const stats=await db().prepare("SELECT COUNT(*) total,COALESCE(SUM(CASE WHEN payment_status='paid' AND mode IN ('manual_qr','live') THEN amount ELSE 0 END),0) sales,COALESCE(SUM(CASE WHEN payment_status='awaiting_review' THEN 1 ELSE 0 END),0) review_count,COALESCE(SUM(CASE WHEN payment_status='paid' AND installation_status!='Completed' AND installation_status!='Cancelled' THEN 1 ELSE 0 END),0) awaiting FROM orders").first();
   return json({orders:orders.results,stats,products:await catalog(true),config:config(),page});
  }
  if(p[1]==='products'&&method==='POST'){
   const b=await body(req);const id=b.id?textValue(b.id,80):crypto.randomUUID();const name=textValue(b.name,100),description=textValue(b.description,300),category=textValue(b.category,40),monogram=textValue(b.monogram,3);if(!/^#[a-fA-F0-9]{6}$/.test(b.color))fail(400,'Warna tidak sah.');
   if(!Array.isArray(b.packages)||!b.packages.length||b.packages.length>8)fail(400,'Sediakan 1 hingga 8 pakej.');
   const stmts=[db().prepare('INSERT INTO products(id,name,category,description,monogram,color,active) VALUES(?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name,category=excluded.category,description=excluded.description,monogram=excluded.monogram,color=excluded.color,active=excluded.active').bind(id,name,category,description,monogram,b.color,b.active?1:0)];
   for(const k of b.packages){const kid=k.id?textValue(k.id,100):crypto.randomUUID();const old:any=await db().prepare('SELECT product_id FROM packages WHERE id=?').bind(kid).first();if(old&&old.product_id!==id)fail(400,'Pakej bukan milik software ini.');if(k.price!==null&&(!Number.isInteger(k.price)||k.price<100||k.price>3000000))fail(400,'Harga mesti sekurang-kurangnya RM1.00 atau kosong.');
    stmts.push(db().prepare('INSERT INTO packages(id,product_id,name,description,price,active) VALUES(?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name,description=excluded.description,price=excluded.price,active=excluded.active').bind(kid,id,textValue(k.name,80),textValue(k.description,300),k.price,k.active?1:0));}
   await db().batch(stmts);return json({ok:true,id});
  }
  if(p[1]==='orders'&&p[2]&&method==='PATCH'){
   const b=await body(req),o=await loadOrder(p[2]);const allowed=o.payment_status==='paid'?['Installation Pending','In Progress','Completed','Cancelled']:['Cancelled'];
   if(!allowed.includes(b.status))fail(400,'Status ini memerlukan pembayaran yang disahkan.');
   await db().prepare('UPDATE orders SET installation_status=? WHERE id=?').bind(b.status,o.id).run();return json({ok:true});
  }
  if(p[1]==='orders'&&p[2]&&method==='POST'){
   const o=await loadOrder(p[2]),b=await body(req);
   if(p[3]==='confirm-payment')return confirmPayment(req,o,b);
   if(p[3]==='reject-receipt')return rejectReceipt(req,o,b);
  }
 }
 return json({error:'Endpoint tidak dijumpai.'},404);
});}
export const GET=handler;export const POST=handler;export const PATCH=handler;
