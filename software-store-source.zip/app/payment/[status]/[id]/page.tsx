import OrderPage from '../../../../components/order-page';
// The status path is presentation only. OrderPage fetches the authorized database state.
export default async function Page({params}:{params:Promise<{status:string,id:string}>}){const {id}=await params;return <OrderPage id={id}/>}