import type { Metadata } from 'next';
import './globals.css';
export const metadata:Metadata={icons:{icon:'/hafis-logo.svg'},title:'Hafis IT Support | Software Installation & Remote Setup',description:'Pilih software dan urus tempahan pemasangan serta remote setup anda dalam satu tempat.'};
export default function Layout({children}:{children:React.ReactNode}){return <html lang="ms"><body>{children}</body></html>}